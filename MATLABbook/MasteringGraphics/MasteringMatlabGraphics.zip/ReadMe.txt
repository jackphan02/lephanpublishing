Mastering MATLAB Graphics


I. INTRODUCTION:

1. The programs and applications on this CD-ROM are tested in Microsoft Windows 2000 and MATLAB 7.0. 

2. All the examples are carefully tested and worked fine in our computer. If you have any error or warning when you compile, please email to us at LePhan@LePhanPublishing.com. We greatly appreciate your feed back for our book.


II. COPYRIGHT:
Copyright of 2004 by LePhan Publishing.
All rights reserved. 
No part of this CD-ROM should be reproduced, or transmitted by any means, electronic, mechanical, photocopying, recording, or otherwise, without written permission from the publisher.


III. DISCLAIMER
The programs and applications on this CD-ROM have been carefully tested, but are not guaranteed for any particular purpose. The publisher does not offer any warranties and does not guarantee the accuracy, adequacy, or completeness of any information and is not responsible for any errors or omissions or the results obtained from use of such information.

IV. TRADEMARK:
MATLAB is a registered trademark of The MathWorks, Inc.
Microsoft Windows is a registered trademark of Microsoft Corporation.


Thank you for your support and having our product.
December 2004.

LePhan Publishing 