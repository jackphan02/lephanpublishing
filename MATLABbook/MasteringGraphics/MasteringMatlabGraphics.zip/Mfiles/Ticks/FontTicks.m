x = -pi:.1:pi;
y = sin(x);
plot(x,y) ;
title('Tick fonts') ;
xlabel('x') ;
ylabel('y') ;

set(gca,'FontName', 'Courier New', 'FontSize', 14, 'FontWeight', 'bold') ;
grid on ;