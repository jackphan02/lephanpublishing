x = -3:.1:3;
y = sin(x);

plot(x,y) ;
title('Distances of ticks')
XLabel('x')
YLabel('y') ;
grid on ;

% distance of X ticks is 0.5
set(gca,'xtick',[-3 :0.5: 3])

% setting distances of Y ticks is 0.25
set(gca,'ytick',[-1 :0.25: 1])


