x = -pi:.1:pi;
y = sin(x);
plot(x,y) ;

% set ticks at particular points
set(gca,'Xtick', [-2.5 -pi/2 0  1  pi/2  2.4]) ;

title('Manual Ticks') ;
xlabel('x') ;
ylabel('y') ;
grid on ;