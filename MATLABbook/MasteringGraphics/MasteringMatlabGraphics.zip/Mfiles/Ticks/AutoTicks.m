t = 0:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ;
title('Auto Ticks') ;
xlabel('x') ;
ylabel('y') ;
grid on ;