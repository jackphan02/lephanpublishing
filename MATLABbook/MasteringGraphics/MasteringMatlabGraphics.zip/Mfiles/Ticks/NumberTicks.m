x = -pi:.1:pi;
y = sin(x);

plot(x,y) ;
title('Number of ticks')
XLabel('x') ;
YLabel('y') ;
grid on ;

%  from range -pi to pi, set 6 ticks with equal distances
set(gca,'xtick', linspace(-pi, pi, 6) ) ;

%  from range -1 to 1, set 8 ticks with equal distances
set(gca,'ytick', linspace(-1, 1, 8) ) ;

