x = -pi:.1:pi;
y = sin(x);
plot(x,y) ;

set(gca,'XMinorTick','on','YMinorTick','on')

title('Minor ticks') ;
xlabel('x') ;
ylabel('y') ;
grid on ;