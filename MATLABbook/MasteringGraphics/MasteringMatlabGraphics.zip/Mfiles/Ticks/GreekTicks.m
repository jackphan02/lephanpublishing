x = -pi:.1:pi;
y = sin(x);

plot(x,y) ;
title('Adding Greek letters for ticks') ;
grid on ;

%remove all ticks
set(gca, 'xticklabel',[]) ;

posTick(1) = -pi      ;
posTick(2) = -pi/6    ;
posTick(3) =  0       ;
posTick(4) =  pi/6    ;
posTick(5) =  pi      ;

labelTick(1) = {'-\pi'}      ;
labelTick(2) = {'-\pi/6'}    ;
labelTick(3) = {'0'}         ;
labelTick(4) =  {'\pi/6'}    ;
labelTick(5) =  {'\pi'}      ;

set(gca,'XTick', posTick)    ; 

%add ticks
Haxis = gca ;
axisPro = get(Haxis) ;
posY = axisPro.YLim(1) ;

for i = 1: 5
 text( posTick(i), posY, labelTick(i), ...
    'HorizontalAlignment', 'center','VerticalAlignment', 'top') ;

end
