x = -pi:.1:pi;
y = sin(x);
plot(x,y) ;

% set the distance for ticks is pi/2
% this will create 5 ticks.
set(gca,'XTick', -pi:pi/2:pi) ; 
% you can set 5 ticks at 5 particular points

%set particular 5 labels for ticks
set(gca,'XTickLabel',{'-pi','-pi/2','0','pi/2','pi'})  
%set(gca,'XTickLabel',{'-aa','start','0','stop','dd'})  
%note that the number of ticks is the same number of your label

title('Label ticks') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
