%inputs: posTick and labelTick

x = -pi:.1:pi;
y = sin(x);
figure ;

plot(x,y) ;

%remove all ticks
set(gca, 'xticklabel',[]) ;

posTick1 = -pi      ;
posTick2 = -pi/2    ;
posTick3 =  0       ;
posTick4 =  pi/2    ;
posTick5 =  pi      ;

lableTick1 = '-\pi'      ;
lableTick2 = '-\pi/2'    ;
lableTick3 =  '0'        ;
lableTick4 =  '\pi/2'    ;
lableTick5 =  '\pi'      ;

set(gca,'XTick', [ posTick1  posTick2  posTick3  posTick4  posTick5 ]) ; 

%get properties of axis
Haxis = gca ;
axisPro = get(Haxis) ;

    %left bottom corner of figure
posX = axisPro.XLim(1) ;
posY = axisPro.YLim(1) ;

%add ticks
text(posTick1, posY, lableTick1,'HorizontalAlignment', 'center','VerticalAlignment', 'top') ;
text(posTick2, posY, lableTick2,'HorizontalAlignment', 'center','VerticalAlignment', 'top') ;
text(posTick3, posY, lableTick3,'HorizontalAlignment', 'center','VerticalAlignment', 'top') ;
text(posTick4, posY, lableTick4,'HorizontalAlignment', 'center','VerticalAlignment', 'top') ;
text(posTick5, posY, lableTick5,'HorizontalAlignment', 'center','VerticalAlignment', 'top') ;


grid on ;
%set(gca, 'xticklabel',{'-pi','-pi/2','0','pi/2','pi'})  , 'fontname','symbol');


%set(gca, 'xticklabel',{'tick1','tick2','tick3','tick4','tick5'}) ;


% tick1font = '\fontname{symbol}';
% tick1size = '\fontsize{32}';
% tick1char1 = 'p' ;
% resettick  = '\fontname{arial}\fontsize{10}';
% tick1char2 = '/2' ;
% tick1 = strcat(tick1font, tick1size, tick1char1, resettick, tick1char2) ;



% 1) Set tick with 2 decimal points
% Sorry that works only for the test case you posted. Maybe this works
% in a more general way:
% 
% set(gca,'XTickLabel',num2str(get...(gca,'XTick')','%.2f'));