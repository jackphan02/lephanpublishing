x = -pi:.1:pi;
y = sin(x);

plot(x,y) ;
set(gca,'XTickLabel',num2str(get(gca,'XTick')','%.4f'));

title('Formatted ticks') ;
xlabel('x') ;
ylabel('y') ;
grid on ;