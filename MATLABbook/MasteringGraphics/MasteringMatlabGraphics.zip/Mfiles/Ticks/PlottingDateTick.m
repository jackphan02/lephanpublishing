[Month, Day, Year, Hour, Minute, Second, data1, data2] = ...
         textread('Data2.txt','%d/%d/%d %d:%d:%d %f %f' );  

total = length(Second) ;
Date = zeros(total,1);

for i= 1: total
ExpTime(i) = datenum( Year(i), Month(i), Day(i), Hour(i), Minute(i), Second(i) );

end

hold on ;

plot(ExpTime, data1, 'b') ;
plot(ExpTime, data2, 'k') ;

title('\bf Expermental Data') ;
xlabel('\bf 02/16/1999')    ;
ylabel('\bf Temperature')   ;

datetick('x','HH:MM') ;

grid on; 
hold off ;


