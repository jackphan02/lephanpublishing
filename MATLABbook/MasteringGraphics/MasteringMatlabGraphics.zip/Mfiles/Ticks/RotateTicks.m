x = -pi:.1:pi;
y = sin(x);
plot(x,y) ;

XTick = get(gca,'XTick');
xticklabel_rotate90(XTick); 
%change the rotating angle from 90 to 60 in xticklabel_rotate90(..)

title('Rotating ticks at 60 degree') ;
xlabel('x') ;
ylabel('y') ;
grid on ;