x = -pi:.1:pi;
y = sin(x);


plot(x,y) ;

title('Multiple lines of X ticks') ;
xlabel('inch') ;
XLabelSecond = 'cm' ;
ylabel('y') ;
grid on ;

adjust0 = 0.2 ;
adjust2 = 1.0 ;
adjust1 = 1.0 ;

% ----------------------------------------------------
% to set a second line of Xtick,
% 1. you just put your second line of Xtick in  HXTickSecond at line 51
% 2. adjust the values adjust0, adjust1, and adjust2
% 3. look at MultipleXTick2.m if you want to set manual second line ticks

% --------------------------------------------------
%get properties of axis
Haxis = gca ;
axisPro = get(Haxis) ;

% position of left bottom corner of figure
leftbottomX = axisPro.XLim(1) ;
leftbottomY = axisPro.YLim(1) ;

%create a buffer text 'aaaa' and set invisible. 
%The purpose is to get the lengths for using
HTextBuffer = text(leftbottomX, leftbottomY, 'aaaa', ...
                  'VerticalAlignment', 'top', 'Visible', 'off' ) ;
HTextObj = get(HTextBuffer) ;

% properties of text 'aaaa'
left    = HTextObj.Extent(1) ;
bott    = HTextObj.Extent(2) ;
width   = HTextObj.Extent(3) ;
height  = HTextObj.Extent(4) ;

secondTextPosY = bott - height ; 

%get positions of ticks
HXTick = get(gca,'XTick');          % tick label
numberOfTick = length(HXTick) ;

%create the second line of XTick. 
HXTickSecond = {'a1'; 'a2'; 'a3'; 'a4'; 'a5'; 'a6'; 'a7'; 'a8'; 'a9'} ;

%add the second line tick
for i=1:numberOfTick 
   SecondLineTickLabel = HXTickSecond(i)  ;
  text(HXTick(i), secondTextPosY, SecondLineTickLabel, ...
       'HorizontalAlignment', 'center','VerticalAlignment', 'bottom') ;
end 

%1. add xlabel for first line
      %get position of the right bottom corner of figure as a benchmark
rightbottomX = axisPro.XLim(2) ;
rightbottomY = axisPro.YLim(1) ;

      %set new postion for XLabel
HXLabelFirst = get(gca,'XLabel') ;
XLabelFistPosX = rightbottomX + adjust1*width   ; % = rightbottomX + distance
XLabelFistPosY = rightbottomY - adjust0*height  ; % = rightbottomY + distance

set( HXLabelFirst, 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top') ;
set(HXLabelFirst, 'Position', [XLabelFistPosX   XLabelFistPosY ] ) ;

%2. add xlabel for second line
   % HXTick(numberOfTick) is value of the last tick.
   % it's also x position of the last tick
   % secondTextPosX = XLabelFistPosX 
   
XLabelFistPosX = HXTick(numberOfTick) + adjust2*width  ;
text(XLabelFistPosX, secondTextPosY, XLabelSecond,'HorizontalAlignment', ...
    'left','VerticalAlignment', 'bottom') ;

