x = 0:1:100;
y = 2*x;

plot(x,y) ;
title('Number of ticks')
XLabel('x') ;
YLabel('y') ;
grid on ;

set(gca,'xtick', [10:5:40 50  80:5:100] ) ;
set(gca,'ytick', [0:8:40   50  80:10:120  160:20:200] ) ;
