x = -pi:.1:pi;
y = sin(x);

plot(x,y) ;
title('Multiple lines of Y ticks')
XLabel('x')
YLabel('inch', 'Rotation', 0) ;
YLabelSecond = 'cm' ;
grid on ;

adjust0 = 1.2 ;
adjust1 = 0.2 ;
adjust2 = 1.4;
% ----------------------------------------------------
% to set a second line of YTick,
% 1. you just put your second line of YTick in  HYTickSecond at line 47
% 2. adjust the values adjust0, adjust1, and adjust2
% 3. look at MultipleYTick2.m if you want to set manual second line ticks

%get properties of axis
Haxis = gca ;
axisPro = get(Haxis) ;

% position of the left bottom corner of figure
leftbottomX = axisPro.XLim(1) ;
leftbottomY = axisPro.YLim(1) ;

%create a buffer text 'aaaa' and set invisible. 
%The purpose is to get the lengths for using
HTextBuffer = text(leftbottomX, leftbottomY, 'aaaa', ...
    'VerticalAlignment', 'top', 'Visible', 'off' ) ;
HTextObj = get(HTextBuffer) ;

left    = HTextObj.Extent(1) ;
bott    = HTextObj.Extent(2) ;
width   = HTextObj.Extent(3) ;
height  = HTextObj.Extent(4) ;

secondTextPosY = bott - height ; 


%get positions of first Y ticks
HYTick = get(gca,'YTick');
numberOfTickY = length(HYTick) ;

%create the second line of XTick. 
HYTickSecond = HYTick*2.54 ;

%create postion X of the second line of XTick. 
secondTextPosX = left - adjust0*width  ;

% create postion Y and add the second line tick
for i=1:numberOfTickY 
    
SecondLineTickYLabel = num2str( HYTickSecond(i) ) ;
secondTextPosY = HYTick(i) ;
text(secondTextPosX, secondTextPosY, SecondLineTickYLabel, ...
    'HorizontalAlignment', 'right','VerticalAlignment', 'middle') ;

end 
% ------------------------------------------ add labels
% 1. add ylabel for first line
    %get position of the left top corner of figure as a benchmark
lefttopX = axisPro.XLim(1) ;
lefttopY = axisPro.YLim(2)  ;

HYLabelFirst = get(gca,'YLabel') ;
set( HYLabelFirst, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top') ;

YLabelFistPosX = lefttopX - adjust1*width    ; % = lefttopX -  adjusted
YLabelFistPosY = lefttopY + adjust2*height   ; % = lefttopY +  adjusted

set(HYLabelFirst,'Position',[YLabelFistPosX   YLabelFistPosY ]) ;

% 2. add ylabel for second line
% set same height of first label
YLabelSecondPosY = YLabelFistPosY ;

text(secondTextPosX, YLabelSecondPosY, YLabelSecond, ...
    'HorizontalAlignment', 'right','VerticalAlignment', 'top') ;




