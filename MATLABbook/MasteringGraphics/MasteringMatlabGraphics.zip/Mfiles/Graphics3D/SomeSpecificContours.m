[x, y, z] = peaks(30);

V = [5.2  0.2  3.4] ;
[c, h] = contour(z, V) ;

clabel(c, h) ; %label for a countour
grid on ;