[x, y, z] = peaks(30);
pcolor(x,y,z) ;
shading interp ;

title('Shading Contour') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;

