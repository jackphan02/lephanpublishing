[x, y, z] = peaks(30);
mesh(x, y, z) ;
title('View point at \it{elevation = 70} and \it{azimuth = 28} degree') ;
view(70, 28) ;

xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
grid on ;
