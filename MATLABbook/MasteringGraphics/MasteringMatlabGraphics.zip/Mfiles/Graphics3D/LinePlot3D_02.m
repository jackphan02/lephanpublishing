% Plotting line 
t = 0:0.01:2*pi ;
u = sin(t) ;
v = cos(t) ;

z = u - v ;

plot3(u, v, z) ;

title('Line Plot') ;
xlabel('sin(t)') ;
ylabel('cos(t)') ;
zlabel('sin(t) - cos(t)') ;

grid on ;
