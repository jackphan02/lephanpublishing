[x, y, z] = peaks(30);
surf(x, y, z) ;

shading flat ;
%shading interp ;
title('Shading surface with flat shading') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
grid on ;

