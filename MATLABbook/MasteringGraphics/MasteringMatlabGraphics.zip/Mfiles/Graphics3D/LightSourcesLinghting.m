[x, y, z] = peaks(30);
surf(x,y,z) ;
shading interp ;

light('Position',[0 -2 4]) ;
lighting flat ; % default of lighting
%lighting gouraud ; 
%lighting phong ; 
%lighting none ; 

title('Adding a light source with lighting flat (default)') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
