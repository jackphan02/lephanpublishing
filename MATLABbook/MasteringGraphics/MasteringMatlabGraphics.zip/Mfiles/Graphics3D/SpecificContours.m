[x, y, z] = peaks(30);

V = [1.05 1.05] ;
[c, h] = contour(z, V) ;

clabel(c, h) ; %label for a countour
grid on ;