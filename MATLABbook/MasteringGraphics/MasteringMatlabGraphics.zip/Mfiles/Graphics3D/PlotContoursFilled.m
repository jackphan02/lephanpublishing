[x, y, z] = peaks(30);
[c, h] = contourf(z) ;

xlabel('x') ;
ylabel('y') ;
clabel(c, h) ; %label for a countour
grid on ;

