[x, y, z] = peaks(30);
surf(x,y,z) ;
shading interp ;

 light('Position',[0 -2 4], 'Color', [1 0 0 ]) ;
%or
%light('Position',[0 -2 4], 'Color', 'red') ;

title('Adding a light source with position = [0 -2 4] and Color = red') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
