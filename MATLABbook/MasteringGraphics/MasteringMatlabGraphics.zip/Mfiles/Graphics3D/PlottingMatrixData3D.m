% Plotting matrix data
[x, y] = meshgrid([-4:0.1:4]) ;
z = 0.5 +  exp(-x.^2 - y.^2) ;
plot3(x, y, z) ;
grid on ;

title('Experimental Force') ;
xlabel('sample length in x direction') ;
ylabel('sample length in y direction') ;
zlabel('Force (N)') ;