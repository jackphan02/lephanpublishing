% Mesh Plots
[x, y] = meshgrid([-4:0.2:4]) ;
z = 0.5 +  exp(-x.^2 - y.^2) ;

mesh(x, y, z) ;
grid on ;

title('Experimental Force') ;
XLabel('sample length in x direction') ;
YLabel('sample length in y direction') ;
ZLabel('Force (N)') ;