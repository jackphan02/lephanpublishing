[x, y, z] = peaks(30);
surf(x,y,z) ;
shading interp ;
light('Position',[-4 4 1]) ;
%light ; % with default position [1 0 1]

title('Adding a light source with position = [-4 4 1]') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
