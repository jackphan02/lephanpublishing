[x, y, z] = peaks(30);
surf(x,y,z) ;
shading interp ;

Hlight = light('Position',[0 -2 4], 'Style', 'local') ;

title('Adding a light source with position = [0 -2 4] and Style = local') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
