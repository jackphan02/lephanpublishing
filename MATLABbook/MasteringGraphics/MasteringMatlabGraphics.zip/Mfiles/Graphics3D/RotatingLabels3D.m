% Plotting matrix data
[x, y] = meshgrid([-4:0.1:4]) ;
z = 0.5 +  exp(-x.^2 - y.^2) ;
plot3(x, y, z) ;
grid on ;

title('Experimental Force') ;
XLabel('sample length in x direction') ;
YLabel('sample length in y direction') ;
ZLabel('Force (N)') ;


HXLabel = get(gca,'XLabel') ;
set(HXLabel,'Rotation', 18.0) ;

HYLabel = get(gca,'YLabel') ;
set(HYLabel,'Rotation', -26.0) ;

