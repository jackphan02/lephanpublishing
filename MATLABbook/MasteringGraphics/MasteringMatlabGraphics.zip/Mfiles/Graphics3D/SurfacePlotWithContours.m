[x, y, z] = peaks(30);
surfc(x,y,z) ;

title('Surface plot with contours') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
grid on ;

