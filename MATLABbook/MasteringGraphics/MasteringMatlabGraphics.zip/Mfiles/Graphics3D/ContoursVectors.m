[x, y, z] = peaks(30);
contour(z) ;

[dx, dy] = gradient(z, 0.5, 0.5);

hold on
quiver3(x, y, dx, dy) ;
hold off

grid on ;
