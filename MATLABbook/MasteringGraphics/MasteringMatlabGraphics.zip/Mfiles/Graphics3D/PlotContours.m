[x, y, z] = peaks(30);
[c, h] = contour(z) ;

clabel(c, h) ; %label for a countour
grid on ;

