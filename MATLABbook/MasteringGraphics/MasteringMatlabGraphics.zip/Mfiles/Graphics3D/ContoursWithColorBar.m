[x, y, z] = peaks(30);
contour(z) ;

colorbar ;
grid on ;