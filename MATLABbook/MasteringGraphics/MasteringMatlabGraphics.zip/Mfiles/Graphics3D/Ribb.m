[x, y, z] = peaks(30);
ribbon(z) ;

xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
grid on ;
