[x, y, z] = peaks(30);
mesh(x, y, z) ;

[nx, ny, nz] = surfnorm(x, y, z);

hold on
quiver3(x, y, z, nx, ny, nz) ;
hold off

grid on ;
