% line plots
t = 0: 0.1: 10*pi ;
u = sin(t) ;
v = cos(t) ;

plot3(u, v, t) ;

title('Helix') ;
XLabel('sin(t)') ;
YLabel('cos(t)') ;
ZLabel('t') ;

grid on ;