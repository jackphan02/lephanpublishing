[x, y, z] = peaks(30);
surf(x,y,z) ;
shading interp ;

light('Position',[0 -2 4]) ;
lighting flat ; 
material dull ;

title('Using the reflectance') ;
xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
