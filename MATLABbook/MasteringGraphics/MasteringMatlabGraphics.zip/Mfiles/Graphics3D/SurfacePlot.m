[x, y, z] = peaks(30);
surf(x, y, z) ;

xlabel('x') ;
ylabel('y') ;
zlabel('z') ;
grid on ;

