% Plotting matrix data
[x, y] = meshgrid([-4:0.1:4]) ;
z = 0.5 +  exp(-x.^2 - y.^2) ;
plot3(x, y, z) ;
grid on ;

% change this number to adjust distances of X and Y labels
AdjustDistanceX = 0.4 ;
AdjustDistanceY = 0.5 ;

title('Experimental Force') ;
ZLabel('Force (N)') ;

% ----------- just add your labels here ---------------- 

%add some empty space for center Y label
XLabel('              sample length in x direction') ;
HXLabel = get(gca,'XLabel') ;
set(HXLabel,'Rotation', 16.0) ;

%add some empty space for center Y label
YLabel('sample length in y direction            ') ;
HYLabel = get(gca,'YLabel') ;
set(HYLabel,'Rotation', -26.0) ;

% ----------- end add your labels  -------------------- 

% ------ protocal to have a good look of labels -------
dumText = '  ' ; %empty text
HdumText = text(0,0,0, dumText, 'Visible', 'off') ;
HdumTextObj = get(HdumText) ;
dumText_height  = HdumTextObj.Extent(4) ;

% ----------------------------------------
HXLabelObj = get(HXLabel) ;
PositionXLabel = HXLabelObj.Position ;
PositionXLabel = PositionXLabel + dumText_height*AdjustDistanceX ;

set(HXLabel,'Position', PositionXLabel) ;
set(HXLabel,'Horizontal', 'center') ;


HYLabelObj = get(HYLabel) ;
PositionYLabel = HYLabelObj.Position ;
PositionYLabel = PositionYLabel + dumText_height*AdjustDistanceY ;

set(HYLabel,'Position', PositionYLabel) ;
set(HYLabel,'Horizontal', 'center') ;

