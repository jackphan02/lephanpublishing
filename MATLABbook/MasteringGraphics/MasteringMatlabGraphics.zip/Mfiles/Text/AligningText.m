t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ; 
text( 150, 0.34, 'text 01', 'HorizontalAlignment', 'left',...
                            'VerticalAlignment'  , 'middle') ;
text( 150, 0.31, 'text 02', 'HorizontalAlignment', 'right',...
                            'VerticalAlignment'  , 'middle') ;

text( 150, 0.17, 'left middle text ', 'HorizontalAlignment', 'left',...
                                      'VerticalAlignment'  , 'middle') ;
text( 310, 0.17, 'top middle text' ,  'HorizontalAlignment', 'left',...
                                     'VerticalAlignment'   ,'top') ;

title('Aligning text') ;
xlabel('x') ;
ylabel('y') ;
grid on ;