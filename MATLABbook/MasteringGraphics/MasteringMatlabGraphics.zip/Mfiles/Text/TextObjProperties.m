t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ; 

Htext = text(150, 0.37, 'mytext') ;
set(Htext, 'fontsize', 14)  ;

title('Set Text') ;
xlabel('x') ;
ylabel('y') ;

