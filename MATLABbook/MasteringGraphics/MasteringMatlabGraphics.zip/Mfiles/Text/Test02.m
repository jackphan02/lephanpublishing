t = 0:20:600 ;
y1 = 0.4 * exp(-0.015*t) ;
y2 = 0.8 * exp(-0.005*t) ;

plot (t, y1,'r+', t, y2, 'go') ;
title('Two lines with different styles and colors') ;
xlabel('x') ;
ylabel('y') ;
grid on ;