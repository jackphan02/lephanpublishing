t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

mystring(1) = {'line 01'} ;
mystring(2) = {'line 02 123456789'}  ;
mystring(3) = {'line 03 abcdefghiABCDEFGHI'} ;

plot (t, y) ; 
text( 300, 0.31, mystring, 'HorizontalAlignment', 'center' ) ;

title('Multiline Text') ;
xlabel('x') ;
ylabel('y') ;
grid on ;