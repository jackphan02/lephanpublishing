t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ; 
text( 150, 0.37, 'default text color') ;


H_textRed = text( 150, 0.32, 'set red color') ;
set(H_textRed, 'Color', 'r') ;

H_textGreen = text( 150, 0.27, 'set green color') ;
set(H_textGreen, 'Color', 'g') ;

title('Text color') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
