chart('symbol') ;
a = hex2dec('DE'); 

t = 0:10:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ;
title('Extra Symbols') ;
xlabel('x') ;
ylabel('y') ;

text(150, 0.32, setstr(a),'fontname','symbol','fontsize', 34) ;
