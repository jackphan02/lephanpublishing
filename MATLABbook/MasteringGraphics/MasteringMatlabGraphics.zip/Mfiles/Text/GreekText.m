t = 0:10:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ;
title('Text Symbols') ;
xlabel('x') ;
ylabel('y') ;

text(150, 0.32, 'y_0 = \alpha + \beta + \gamma') ;
text(150, 0.27, 'y_1 = \alphax^2 + \betax + \gamma') ;
text(150, 0.22, 'y_2 = \bf\alpha + \it\beta + \gamma') ;


