t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ; 
text( 150, 0.37, 'a basic text') ;

title('A basis text') ;
xlabel('x') ;
ylabel('y') ;
grid on ;