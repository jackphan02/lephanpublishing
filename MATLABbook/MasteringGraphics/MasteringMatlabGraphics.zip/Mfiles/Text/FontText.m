t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ; 
text( 150, 0.31, 'Text Font', 'FontSize', 16,...
                              'FontName', 'Courier New', ...
                              'FontWeight', 'bold' )  ;

title('Text Font') ;
xlabel('x') ;
ylabel('y') ;
grid on ;