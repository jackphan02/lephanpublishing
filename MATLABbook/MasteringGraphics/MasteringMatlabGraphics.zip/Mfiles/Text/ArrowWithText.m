x = -pi:.1:pi;
y = sin(x);

plot(x,y) ;

title('Drawing an arrow with text')
XLabel('x') ;

YLabel('y') ;
grid on ;

% point A
PointAx = -2.0 ;
PointAy = 0.6 ;

Htext = text(PointAx, PointAy, 'considering point') ;
set(Htext, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom') ;

% point B
PointBx = 0.0 ;
PointBy = 0.0 ;

PointsXval = [PointAx PointBx] ;
PointsYval = [PointAy PointBy] ;

%draw a line from point A to point B
line( [PointAx PointBx], [PointAy PointBy] ) ;

%create a big arrow head with blue color
arrowh(PointsXval, PointsYval, 'b') ;