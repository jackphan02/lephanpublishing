t = 0:10:600 ;
y = 0.4 * exp(-0.015*t) ;
Hfig = plot (t, y) ;

mycolor = [0.67  0  1] ;
set(Hfig, 'Color', mycolor) ;

title('A chosen color for line') ;
xlabel('x') ;
ylabel('y') ;
grid on ;