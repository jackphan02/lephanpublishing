t = linspace(0, 2*pi, 20) ;
y1 = cos(t) ;
y2 = cos(t + pi/4) ;
y3 = cos(t + pi/3) ;
y4 = cos(t + pi/2) ;

subplot(2,2,1)
plot(t, y1) ;
text(3, 0.5, 'plot 1') ;
title('Plot 1') ;

subplot(2,2,2)
plot(t, y2) ;
text(4, -0.5, 'plot 2') ;
title('Plot 2') ;

subplot(2,2,3)
plot(t, y3) ;
text(2, 0, 'plot 3') ;
title('Plot 3') ;

subplot(2,2,4)
plot(t, y4) ;
text(4, -0.75, 'plot 4') ;
title('Plot 4') ;

