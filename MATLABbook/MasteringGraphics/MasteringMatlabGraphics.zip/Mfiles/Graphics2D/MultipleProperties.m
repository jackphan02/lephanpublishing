t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

%plot(t, y, 'Color', 'red', 'LineWidth', 2.5) 
 Hfig = plot(t, y) ;
 set( Hfig, 'Color', 'red') ;
 set( Hfig, 'LineWidth', 2.5) ;

title('Mutiple Properties') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
