t = linspace(0, 2*pi, 20) ;

y1 = cos(t) ;
y2 = cos(t + pi/3) ;
y3 = cos(t + 2*pi/3) ;

hold on ;

Hplot1 =  plot (t, y1) ; 
Hplot2 =  plot (t, y2) ; 
Hplot3 =  plot (t, y3) ; 

set(Hplot1, 'Color', 'r', 'Marker', '*', 'LineStyle', 'none') ;
set(Hplot2, 'Color', 'b', 'LineStyle', '--') ;

set(Hplot3, 'Color', 'k', 'Marker', 'o') ;

hold off ;

title('Multiple Lines') ;
xlabel('x') ;
ylabel('y') ;
grid on ;

