x = -pi:.1:pi;
y = sin(x);

plot(x,y) ;
title('Drawing lines')
xlabel('x') ;
ylabel('y') ;
grid on ;

% point A
A = [0.5, 0.8] ;

% point B
B = [2.0, -0.8] ;

line(  [A(1), B(1)], [A(2), B(2)]  ) ;


