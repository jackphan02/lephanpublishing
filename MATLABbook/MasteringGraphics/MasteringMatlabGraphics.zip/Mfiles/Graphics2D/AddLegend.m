t = linspace(0, 2*pi, 20) ;

y1 = cos(t) ;
y2 = cos(t + pi/3) ;
y3 = cos(t + 2*pi/3) ;

hold on ;

Hplot1 =  plot (t, y1) ; 
Hplot2 =  plot (t, y2) ; 
Hplot3 =  plot (t, y3) ; 

set(Hplot1, 'Color', 'r', 'Marker', '*', 'LineStyle', '-') ;
set(Hplot2, 'Color', 'b', 'Marker', '^', 'LineStyle', 'none') ;
set(Hplot3, 'Color', 'k', 'Marker', 'o', 'LineStyle', '--') ;

string1 = 'plot 1' ;
string2 = 'plot 2' ;
string3 = 'plot 3' ;

pos = 4 ;

Hlegend = legend(string1, string2, string3, pos) ;
set(Hlegend, 'FontWeight', 'bold') ;
legend('boxoff') ;

hold off ;

title('Figure Legends') ;
xlabel('x') ;
ylabel('y') ;
grid on ;