t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ; 

Htext = text(150, 0.27, 'my text') ;
set(Htext, 'EdgeColor', 'r') ;

title('Text in Box') ;
xlabel('x') ;
ylabel('y') ;