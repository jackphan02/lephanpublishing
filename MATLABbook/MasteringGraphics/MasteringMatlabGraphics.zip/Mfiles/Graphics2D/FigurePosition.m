t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot(t, y) ;
LeftBottomPointX = 0.25 ;
LeftBottomPointY = 0.3   ;

% figure size (default 100% is 1 of the gray area)
FigWidth     = 0.5;
FigHeight    = 0.5 ;
 
myFigPos = [LeftBottomPointX LeftBottomPointY FigWidth FigHeight] ;
set(gca,'Position', myFigPos ) ;

title('The figure position') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
