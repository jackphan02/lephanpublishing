t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

figure ;
hold on ;

mycolor = [0.67  0  1] ;

plot (t, y, 'Color', mycolor) ;
plot (t, y, 'ro') ; % red and circle symbol

title('Plotting markers and the line') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
hold off ;