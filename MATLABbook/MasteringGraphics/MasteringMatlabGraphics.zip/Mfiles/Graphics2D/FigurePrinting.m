t = logspace(-1,3);  
y = exp(t)   ;

Hplot = plot(t, y) ;

title('Figure Printing') ;
xlabel('x ') ;
ylabel('y') ;
grid on ;

%%% ----------------------------------------------------------------
% set paper in landscape and picture in the center of the pager
set(gcf, 'PaperOrientation', 'landscape') ;
% unit: inch, and default values
pictureWidth  = 8 ; 
pictureHeight = 6 ;

%paper in landscaple
paperWidth  = 11 ;
paperHeight = 8.5 ;

pictureleft     = ( paperWidth  - pictureWidth  )/ 2 ;
picturebottom   = ( paperHeight - pictureHeight )/ 2 ;

set(gcf, 'PaperPosition', [pictureleft picturebottom pictureWidth pictureHeight]) ;
%%% ----------------------------------------------------------------