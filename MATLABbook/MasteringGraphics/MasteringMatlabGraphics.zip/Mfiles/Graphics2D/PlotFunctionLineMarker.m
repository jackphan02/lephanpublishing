t = 0:10:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y, '*') ;
title('Line Marker') ;
xlabel('x') ;
ylabel('y') ;
grid on ;