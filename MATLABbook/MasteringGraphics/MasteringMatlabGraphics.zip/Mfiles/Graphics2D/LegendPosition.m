t = 0:10:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ; 

string = 'my legend' ;
Hlegend = legend(string) ;

set(Hlegend, 'Position', [0.5 0.5 0.2 0.1 ] ) ;

title('Legend Position') ;
xlabel('x') ;
ylabel('y') ;
grid on ;