x = -pi:.1:pi;
y = sin(x);

plot(x,y) ;
grid on ;
title('Drawing horizontal and vertical lines')
XLabel('x') ;
YLabel('y') ;
grid on ;


%draw a horizontal line at y = 0.25
LineAtY = 0.25 ;

%draw a vertical line at x = -pi/4
LineAtX = -pi/4 ;

% -------------protocol of drawing a vertical line ---------
Haxis = gca ;
axisProperty = get(Haxis) ;

%top and bottom values of figure
topY    = axisProperty.YLim(2) ;
bottomY = axisProperty.YLim(1) ;

PointThroughX_top = [LineAtX   topY]    ;
PointThroughX_bot = [LineAtX   bottomY] ;

line( [LineAtX  LineAtX], [topY  bottomY]) ;

% -------------protocol of drawing a horizontal line ------
%Haxis = gca ;
%axisProperty = get(Haxis) ;

% left and right values of figure
leftX  = axisProperty.XLim(1) ;
rightX = axisProperty.XLim(2) ;

PointThrough_left = [leftX    LineAtY]  ;
PointThrough_bot  = [rightX   LineAtY]  ;

line( [leftX  rightX], [LineAtY, LineAtY]) ;

% set red color for this line
%lh = line( [leftX  rightX], [LineAtY, LineAtY]) ;
%set(lh, 'color', 'r') ;

