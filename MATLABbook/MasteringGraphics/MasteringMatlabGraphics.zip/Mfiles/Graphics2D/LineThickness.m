t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y, 'LineWidth', 3.2) ;

title('Line thickness') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
