t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
Hplot = plot (t, y) ; 

title('Properties of the plotting line') ;
xlabel('x') ;
ylabel('y') ;