t = 0:10:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y, 'r+') ;
title('line marker and color') ;
xlabel('x') ;
ylabel('y') ;
grid on ;