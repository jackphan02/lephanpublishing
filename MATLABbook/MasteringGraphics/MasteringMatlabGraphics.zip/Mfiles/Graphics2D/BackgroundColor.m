t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y, 'r') ; % curve color is red

%back ground color for the outside figure
%set(gcf, 'Color', 'b' ) ;

%back ground color for the inside figure
set(gca,  'Color', 'b' ) ;

%for keep the background color when export
set(gcf, 'InvertHardCopy', 'off'); 

title('Background color') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
