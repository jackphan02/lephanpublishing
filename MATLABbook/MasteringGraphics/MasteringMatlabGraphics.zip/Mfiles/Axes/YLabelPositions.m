t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ;

title('Y Label Position') ;
xlabel('x') ;
ylabel('y') ;
grid on ;

% --------------- set Y label to bottom or top of graphics
HYLabel = get(gca, 'YLabel') ; % get current Y label
HYLabelProperty = get(HYLabel) ; % get properties of Y label
YLabelPos = HYLabelProperty.Position ; % get default of position

Haxes = get(gca) ;  % get current axes
%YLabelPos(2) = Haxes.YLim(1) ; % get min of y, for moving to bottom
YLabelPos(2) = Haxes.YLim(2) ; % get max of y, for moving to top
set(HYLabel, 'Position', YLabelPos) ; % set again position



