t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ;

axis([-Inf 280  0.02  Inf]) ;

title('Semiautomatic Axes Limits') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
