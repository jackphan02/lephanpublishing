t = 0:1:100000;
y = 0.4 * exp(-0.015*t) ;

semilogx(t, y) ;

title('Logarithmic scale for only x axis') ;
xlabel('Logarithmic scale') ;
ylabel('Linear scale') ;
grid on ;




