t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ;

title('X Label Positions') ;
xlabel('x') ;
ylabel('y') ;
grid on ;


% --------------- set X label at beginning or end of graphics
HXLabel = get(gca, 'XLabel') ; % get current X label
HXLabelProperty = get(HXLabel) ; % get properties of X label
XLabelPos = HXLabelProperty.Position ; % get default of position

Haxes = get(gca) ;  % get current axes
%XLabelPos(1) = Haxes.XLim(1) ; get min of x, for moving to left
XLabelPos(1) = Haxes.XLim(2) ; % get max of x, for moving to right
set(HXLabel, 'Position', XLabelPos) ; % set again position




