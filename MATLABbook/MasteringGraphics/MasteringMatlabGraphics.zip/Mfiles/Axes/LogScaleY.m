t = 0:1:10  ;
y = 10.^t   ;

semilogy(t, y) ;

title('Logarithmic scale for only y axis') ;
xlabel('Linear scale ') ;
ylabel('Logarithmic scale') ;
grid on ;




