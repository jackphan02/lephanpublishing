t = 0:pi/40:2*pi ;
plot (sin(t), cos(t)) ;

%gca: get current axes
set(gca, 'DataAspectRatio', [0.5  0.75  1] ) ;

title('Axes Aspect Ratio, x=0.5, y=0.75, and z = 1') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
