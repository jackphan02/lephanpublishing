t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ;

%gca:  get current axes
set(gca, 'Xlim', [50 280]) ; 
set(gca, 'Ylim', [0.02  0.25]) ; 
%or
%axis([50 280  0.02  0.25]) ;

title('Axes Limits') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
