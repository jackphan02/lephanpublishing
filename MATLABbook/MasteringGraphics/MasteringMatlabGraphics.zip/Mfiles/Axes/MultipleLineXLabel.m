% Plotting matrix data
[x, y] = meshgrid([-4:0.1:4]) ;
z = 0.5 +  exp(-x.^2 - y.^2) ;
plot3(x, y, z) ;
grid on ;

title('Experimental Force') ;

YLabel('sample length in y direction') ;
ZLabel('Force (N)') ;

HZLabel = get(gca, 'ZLabel') ;

myYLabel(1) = {'sample length in x direction'}    ;
myYLabel(2) = {'other'}   ;


HXLabel = get(gca,'XLabel') ;
set(HXLabel,'Rotation', 18.0) ;

HYLabel = get(gca,'YLabel') ;
set(HYLabel,'Rotation', -26.0) ;
set(HYLabel,'VerticalAlignment', 'bottom') ;

XLabel(myYLabel) ;

%set(HYLabel,'Horizontal', 'right') ;

Haxes = get(gca) ;