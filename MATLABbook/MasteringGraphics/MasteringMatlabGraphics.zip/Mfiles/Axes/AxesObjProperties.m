t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ; 

set(gca, 'XColor', 'r') ;
title('Set Axes Properties') ;
xlabel('x') ;
ylabel('y') ;
grid on ;

