t = 0:30:1000  ;
y1 = 800*exp(-0.005*t)   ;
y2 = sin(0.005*t) ;

[Haxes, Hline1, Hline2] = plotyy (t,y1, t,y2, 'semilogy', 'plot') ;
title('Plotting with Linear and Logarithmic Y-Axes') ;

% setting properties for the plot 1
Axis1 = Haxes(1) ;
set(Axis1, 'Ygrid', 'on') ;
set(Axis1, 'Xgrid', 'on') ;

Axis1_YLabel = get( Axis1, 'YLabel') ;
set(Axis1_YLabel, 'string', 'Linear scale') ;
set(Hline1, 'LineStyle', '--') ;

% setting properties for the plot 2
Axis2 = Haxes(2) ;
set(Axis2, 'Ygrid', 'on') ;
set(Axis2, 'YColor', 'r') ;

Axis2_YLabel = get( Axis2, 'YLabel') ;
set(Axis2_YLabel, 'string', 'Logarithmic scale') ;

set(Hline2, 'Color', 'r') ;
set(Hline2, 'Marker', 'o') ;

