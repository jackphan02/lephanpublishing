t = 0:pi/40:2*pi ;
plot (sin(t), cos(t)) ;

axis square ;

title('Axes Aspect Ratio in \bfsquare') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
