t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plot (t, y) ;

title('Multiple Lines of Axes Labels') ;

XLabel({'inch'; 'cm'}) ;
HXLabel = get(gca, 'XLabel') ; 

set(HXLabel, 'Fontsize', 16) ;
set(HXLabel, 'Color', 'r') ;

YLabel({'^oC'; '^oF'}) ;
HYLabel = get(gca, 'YLabel') ; 

set(HYLabel, 'Fontsize', 16) ;
set(HYLabel, 'Color', 'r') ;

grid on ;
% -------- shrinking the figure to show labels -------------------
% ---------see Chapter Two-Dimensional Graphics -------------------
LeftBottomPointX = 0.25 ;
LeftBottomPointY = 0.3   ;

FigWidth     = 0.5;
FigHeight    = 0.5 ;
 
myFigPos = [LeftBottomPointX LeftBottomPointY FigWidth FigHeight] ;
set(gca,'Position', myFigPos ) ;


