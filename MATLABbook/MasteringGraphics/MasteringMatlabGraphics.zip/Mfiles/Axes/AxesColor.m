t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y, 'b') ; % curve color is blue

Haxes = gca ; % get current axes
set(Haxes, 'XColor', 'r') ;  % red color for x
set(Haxes, 'YColor', 'g') ;  % green color for y

%we can use
%mycolor = [0.67  0  1] ;
%set(Haxes, 'XColor', mycolor) ;

title('Axes color') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
