t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ;
% gca: get current axis
set( gca, 'XDir', 'reverse' );
 
% for inverse axis y
%set( gca,'YDir', 'reverse' ); 

title('Inverse axis X') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
