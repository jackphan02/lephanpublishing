t = logspace(-1,3);  
y = exp(t)   ;

loglog(t, y) ;

title('Logarithmic scale for both x and y axes') ;
xlabel('Logarithmic scale ') ;
ylabel('Logarithmic scale') ;
grid on ;




