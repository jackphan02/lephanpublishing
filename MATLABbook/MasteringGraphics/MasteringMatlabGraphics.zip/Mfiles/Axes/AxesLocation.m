t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;

plot (t, y) ;
%gca : get current axis

%set(gca,  'XAxisLocation', 'top' ) ;
 set(gca,  'YAxisLocation', 'right' ) ;

title('Axes locations') ;
xlabel('x') ;
ylabel('y') ;
grid on ;
