t = 0:20:600 ;
y = 0.4 * exp(-0.015*t) ;
plotyy(t, y, t, y) ;

title('Two Y-Axes') ;
xlabel('x') ;
ylabel('y') ;
grid on ;




