//
//  BleCommViewModel.swift
//  BleFrame
//
//  Created by Jack Phan on 6/11/23.
//

import SwiftUI
import CoreBluetooth

class BleCommViewModel: NSObject, ObservableObject {
    
    @Published var centralManager: CBCentralManager?
    @Published var foundOnePeripheral: UserBlePeripheral!
    @Published var foundPeripherals: [UserBlePeripheral] = []
    @Published var connectedUserBlePeripheral: UserBlePeripheral?
    @Published var foundServiceName : String = " "       // to quick update Service info on DetailView
        
    override init() {
        super.init()
        self.centralManager = CBCentralManager(delegate: self, queue: .main)
    }
    
}

extension BleCommViewModel: CBCentralManagerDelegate, CBPeripheralDelegate {
 
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        print("step 1")
        if(central.state == .poweredOn) {
            self.centralManager?.scanForPeripherals(withServices: nil)
            print("step 2")
        }
        
        switch central.state {
                
            case .poweredOff:
                print("Power is Off")
                
            case .poweredOn:
                print("Power is On, scanning Ble devices")
                self.centralManager?.scanForPeripherals(withServices: nil)
                
            case .unsupported:
                print("Unsupport")
                
            case .unauthorized:
                print("Unauthorized")
                
            case .unknown:
                print("Unknown")
                
            case .resetting:
                print("Resetting")
                
            @unknown default:
                print("Error")
                
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
            
        foundOnePeripheral = UserBlePeripheral (
            _userPeripheral: peripheral,
            _userServices: [],
            _name: peripheral.name ?? "no name",
            _rssi: RSSI.intValue
            )
        
        // option 1: will store multiple times one one device
        // foundPeripherals.append(foundOnePeripheral)
        
        // option 2: set filter to get unique
        if !IsInFoundPeripherals(foundOnePeripheral) {
            foundPeripherals.append(foundOnePeripheral)
        }
                
    }
    
    func IsInFoundPeripherals (_ onePeripheral: UserBlePeripheral) -> Bool {
        
        // scanning filter
        for item in foundPeripherals {
            
            if item.userPeripheral.identifier.uuidString == onePeripheral.userPeripheral.identifier.uuidString {
                return true
            }
        }
        
        // not match any, this device, onePeripheral, wasn't found
        return false
    }
    
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {

        print("Disconnected device")
        resetConfigure()
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
                
        print("One device conected")
        peripheral.delegate = self;
        
        // establish a connected device
        connectedUserBlePeripheral = UserBlePeripheral(
            _userPeripheral: peripheral,
            _userServices: [],
            _name: peripheral.name ?? "not provided name",
            _rssi: foundOnePeripheral.rssi
        )
        
        peripheral.discoverServices(nil)
        print("Getting services")
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        
        peripheral.services?.forEach { oneService in
            
            let serName = getServiceName(serviceDescription: oneService.description)
            print("Service info:\n \(oneService.description)")
            print("\nService name: \(serName)")
            
            foundServiceName = serName
            
            let foundOneService: UserBleService = UserBleService (
                                                    _uuid: oneService.uuid,
                                                    _service: oneService,
                                                    _serviceName: serName,
                                                    _userCharacteristices: []
                                                    )
            
            // setup for user
            let oneUserBleService: UserBleService = UserBleService (
                _uuid: foundOneService.uuid,
                _service: foundOneService.service,
                _serviceName: serName,
                _userCharacteristices: []
            )
            connectedUserBlePeripheral?.userServices.append(oneUserBleService)
            
            print("Found one service: \(foundOneService.uuid.uuidString)")
            peripheral.discoverCharacteristics(nil, for: foundOneService.service)
        }
        
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?)
    {
    
        // set descriptor on each characteristic
        service.characteristics?.forEach { characteristic in
            
            // setup for user
            let foundOneUserChar : UserBleCharacteristic = UserBleCharacteristic(
                _characteristic: characteristic,
                _uuid: characteristic.uuid
                )
                        
            // add this found-characteristic to the service
            // check to make sure it matches with this service
            for item in connectedUserBlePeripheral?.userServices ?? [] {
                
                if item.uuid.uuidString == service.uuid.uuidString {
                    
                    print("Found one characteristic: \(foundOneUserChar.uuid.uuidString)")
                    item.userCharacteristices.append(foundOneUserChar)
                }
            }
            
        }
    }
    
    func getServiceName(serviceDescription: String) -> String {
        
        let target = "UUID = "
        if let range = serviceDescription.range(of: target) {
            let uuidRange = range.upperBound..<serviceDescription.endIndex
            var serviceName = String(serviceDescription[uuidRange])
            
            if serviceName.hasSuffix(">") {
                serviceName.removeLast()
            }
            return serviceName;
        }
        else {
            
            return " "
        }
        
    }

    func resetConfigure() {
        withAnimation {
            connectedUserBlePeripheral = nil
        }
    }

    
}

