//
//  UserBleCharacteristic.swift
//  BleFrame
//
//  Created by Jack Phan on 8/17/23.
//

import CoreBluetooth

class UserBleCharacteristic: Identifiable, ObservableObject {
    @Published var id: UUID
    @Published var characteristic: CBCharacteristic
    @Published var uuid: CBUUID
    
    init(_characteristic: CBCharacteristic,
         _uuid: CBUUID
         
    ) {
        
        id = UUID()
        characteristic = _characteristic
        uuid = _uuid
        
    }
    
}

