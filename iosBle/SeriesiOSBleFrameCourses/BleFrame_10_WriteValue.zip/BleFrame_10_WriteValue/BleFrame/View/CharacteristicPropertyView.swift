//
//  CharacteristicPropertyView.swift
//  BleFrame
//
//  Created by Jack Phan on 8/24/23.
//

import SwiftUI
import Foundation
import CoreBluetooth

struct CharacteristicPropertyView: View {
    
    @StateObject public var oneChar: UserBleCharacteristic
    @StateObject public var oneDevPeri: UserBlePeripheral
    @StateObject var bleObj:  BleCommViewModel
    @State private var showAlert = false
    @State private var recNotiVal = [" ", " ", " "]
    @State private var sendingBytes: [UInt8] = [0,0,0,0 ,0,0,0,0]
    @State private var writeBytes: [UInt16] = [0,0,0,0 ,0,0,0,0]
    @State private var showError = false
    
    var body: some View {
        
        Text("Chars: \(oneChar.characteristicName)")
        Text(" \(oneChar.uuid.uuidString)")

        Spacer().frame(height: 20)
        // MARK: - Chars property permission
        Grid(horizontalSpacing: 70, verticalSpacing: 10) {
                    
            GridRow {
                Text("Readable").gridColumnAlignment(.trailing)
                if isCharsReadable() { Text("Yes") }
                else { Text("No") }

            }

            GridRow {
                Text("Writeable").gridColumnAlignment(.trailing)
                if isCharsWriteable() { Text("Yes") }
                else { Text("No") }

            }
            
            GridRow {
                Text("Notification").gridColumnAlignment(.trailing)
                if isCharsNotification() { Text("Yes") }
                else { Text("No") }

            }

        }
        
        // MARK: - end: Chars properties
        
        // MARK: - Chars perperty operation
        VStack (alignment: .leading){
            Spacer().frame(height: 20)
            
            // MARK: - NOTIFICATION
            HStack (alignment: .center) {
                if isCharsNotification() {
                    
                    Spacer().frame(width: 10)
                    if !oneChar.characteristic.isNotifying {
                        
                        Button(action: {
                            if oneDevPeri.userPeripheral.state != CBPeripheralState.connected {
                                print("NOT CONNECTED")
                                showAlert = true
                            }
                            else {
                                
                                // will set enble notification
                                oneDevPeri.userPeripheral.setNotifyValue(true, for: oneChar.characteristic)
                            }
                            
                        })  {
                            Text("Enable notification")
                                .padding()
                                .frame(width: 170.0, height: 40.0)
                                .foregroundColor(Color.white)
                                .background(Color.blue)
                                .cornerRadius(8)
                        }
                        
                        Spacer().frame(width: 25)
                        Text("Notification is OFF")
                        
                    }
                    else {
                        
                        Button(action: {
                            
                            if oneDevPeri.userPeripheral.state != CBPeripheralState.connected {
                                print("NOT CONNECTED")
                                showAlert = true

                            }
                            else {
                                // will set disable notification
                                oneDevPeri.userPeripheral.setNotifyValue(false, for: oneChar.characteristic)
                            }
                            
                        })  {
                            Text("Disable notification")
                                .frame(width: 170.0, height: 40.0)
                                .foregroundColor(Color.white)
                                .background(Color.red)
                                .cornerRadius(8)
                        }
                        
                        Spacer().frame(width: 25)
                        Text("Notification is ON")

                    }
                    
                }
            }
            
            if isCharsReadable() || isCharsNotification() {
                HStack {
                    List {
                        Text(recNotiVal[2])
                        Text(recNotiVal[1])
                        Text(recNotiVal[0])
                    }
                    .frame(height: 180)
                }
            }

            // MARK: - END NOTIFICATION

            // MARK: - READABLE
            if isCharsReadable() {
                HStack(alignment: .center) {
                
                    Spacer().frame(width: 10)
                    Button(action: {
                        // will perform reading here
                        oneDevPeri.userPeripheral.readValue(for: oneChar.characteristic)
                        
                    }) {
                        Text("Read value (hex)")
                            .padding()
                            .frame(width: 175.0, height: 40.0)
                            .foregroundColor(Color.white)
                            .background(Color.green)
                            .cornerRadius(8)
                    }
                                        
                    Spacer()
                }
                
                Spacer().frame(height: 10)
                
            }
            // MARK: - END READABE
            
            // MARK: - WRIABLE
            if isCharsWriteable() {
                
                // MARK: - BUTTON WRITE
                HStack {
                        Spacer().frame(width: 10)
                        Button(action: {
                            
                            if oneDevPeri.userPeripheral.state != CBPeripheralState.connected {
                                showAlert = true
                            }
                            else {
                               
                                oneDevPeri.userPeripheral.writeValue(Data(sendingBytes),
                                                                     for: oneChar.characteristic,
                                                                     type: .withoutResponse)
                            }

                        })  {
                            Text("Write to")
                                .padding()
                                .frame(width: 170.0, height: 40.0)
                                .foregroundColor(Color.white)
                                .background(Color.purple)
                                .cornerRadius(8)
                        }
                    Spacer()
                }
            }
            
            // MARK: - WRITE ARRAY
            HStack(alignment: .center, spacing: 10) {
                Spacer().frame(width: 20)
                
                Text("byte 0")
                TextField("0", value: Binding(
                    get: { writeBytes[0] },
                    set: { newValue in
                        if newValue >= 0 && newValue <= 255 {
                            writeBytes[0] = UInt16(newValue)
                        } else {
                            showError = true
                        }
                    }
                ), formatter: NumberFormatter())
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .frame(width: 85.0, height: 25.0)
                .padding(4)
                .overlay(
                    RoundedRectangle(cornerRadius: 4)
                        .stroke(Color.orange, lineWidth: 1)
                )
                .alert(isPresented: $showError) {
                    Alert(title: Text("Invalid Input"), message: Text("Please enter a value between 0 and 255"), dismissButton: .default(Text("OK")))
                }
                
                Spacer().frame(width: 5)
                Text("byte 1")
                TextField("1", value: Binding(
                    get: { writeBytes[1] },
                    set: { newValue in
                        if newValue >= 0 && newValue <= 255 {
                            writeBytes[1] = UInt16(newValue)
                        } else {
                            showError = true
                        }
                    }
                ), formatter: NumberFormatter())
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .frame(width: 85.0, height: 25.0)
                .padding(4)
                .overlay(
                    RoundedRectangle(cornerRadius: 4)
                        .stroke(Color.orange, lineWidth: 1)
                )
                .alert(isPresented: $showError) {
                    Alert(title: Text("Invalid Input"), message: Text("Please enter a value between 0 and 255"), dismissButton: .default(Text("OK")))
                }

                
                
                Spacer()
            }

            // MARK: - end WRITE ARRAY

            // MARK: - end WRIABLE
        }
        .onReceive(bleObj.$recValueData) { newVal in

            let recArray = [UInt8](newVal ?? Data())
            let valStr = recArray.map { String(format: "%02X", $0) }.joined(separator: " ")
            recNotiVal.append(valStr)
            
            // Remove the oldest value
            if recNotiVal.count > 0 {
                recNotiVal.removeFirst()
            }

        }
        .alert("Device disconnected", isPresented: $showAlert) {
            }
        
        Spacer()
    }
    
    func isCharsReadable() -> Bool {
        
        if(oneChar.characteristic.properties.rawValue &
           CBCharacteristicProperties.read.rawValue) == 0 {
            return false
        }
        else {
            return true
        }
    }
    
    func isCharsWriteable() -> Bool {
        
        if(oneChar.characteristic.properties.rawValue &
           CBCharacteristicProperties.write.rawValue) == 0 {
            return false
        }
        else {
            return true
        }
    }
    
    func isCharsNotification() -> Bool {
        
        if(oneChar.characteristic.properties.rawValue &
           CBCharacteristicProperties.notify.rawValue) == 0 {
            return false
        }
        else {
            return true
        }
    }
}

